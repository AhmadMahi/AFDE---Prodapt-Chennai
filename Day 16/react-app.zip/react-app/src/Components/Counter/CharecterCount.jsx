import { useState, useEffect } from "react";

function CharacterCounter() {
  // =====================
  // State
  // =====================

  const [text, setText] = useState("");

  // =====================
  // Effects
  // =====================

  useEffect(() => {
    document.title = `${text.length} Characters`;
  }, [text]);

  // =====================
  // Styles
  // =====================

  const styles = {
    container: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      minHeight: "80vh",
    },

    card: {
      width: "600px",
      padding: "35px",

      background: "rgba(255,255,255,0.15)",
      backdropFilter: "blur(25px)",

      borderRadius: "25px",

      boxShadow:
        "0 20px 50px rgba(0,0,0,0.15)",

      textAlign: "center",
    },

    title: {
      marginBottom: "25px",
      color: "#4f46e5",
      fontSize: "2rem",
    },

    textarea: {
      width: "100%",
      height: "180px",

      padding: "15px",

      borderRadius: "15px",

      border: "1px solid #ddd",

      fontSize: "1rem",

      resize: "none",

      boxSizing: "border-box",
    },

    counterBox: {
      marginTop: "25px",

      padding: "20px",

      borderRadius: "15px",

      background:
        "rgba(255,255,255,0.25)",
    },

    count: {
      fontSize: "3rem",
      fontWeight: "bold",
      color: "#4f46e5",
      margin: 0,
    },

    label: {
      color: "#555",
      marginTop: "10px",
    },
  };

  // =====================
  // JSX
  // =====================

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h1 style={styles.title}>
          Character Counter
        </h1>

        <textarea
          placeholder="Start typing..."
          value={text}
          onChange={(e) =>
            setText(e.target.value)
          }
          style={styles.textarea}
        />

        <div style={styles.counterBox}>
          <h2 style={styles.count}>
            {text.length}
          </h2>

          <p style={styles.label}>
            Characters Typed
          </p>
        </div>
      </div>
    </div>
  );
}

export default CharacterCounter;