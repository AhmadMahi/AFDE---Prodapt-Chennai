import { useState } from "react";

function LoginForm() {
  // =====================
  // State
  // =====================

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // =====================
  // Logic
  // =====================

  const handleSubmit = (e) => {
  e.preventDefault();

  if (!email || !password) {
    alert("Please fill all fields");
    return;
  }

  alert("Login Successful");
};

  // =====================
  // Styles
  // =====================

  const styles = {
    container: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      minHeight: "80vh",
    },

    card: {
      width: "400px",
      padding: "35px",

      background: "rgba(255,255,255,0.15)",
      backdropFilter: "blur(25px)",

      borderRadius: "25px",

      boxShadow:
        "0 20px 50px rgba(0,0,0,0.15)",
    },

    title: {
      textAlign: "center",
      marginBottom: "25px",
      color: "#4f46e5",
    },

    input: {
      width: "100%",
      padding: "14px",
      marginBottom: "15px",

      borderRadius: "12px",

      border: "1px solid #ddd",

      boxSizing: "border-box",

      fontSize: "1rem",
    },

    button: {
      width: "100%",
      padding: "14px",

      border: "none",

      borderRadius: "12px",

      background:
        "linear-gradient(135deg,#4f46e5,#7c3aed)",

      color: "white",

      fontWeight: "bold",

      cursor: "pointer",
    },
  };

  // =====================
  // JSX
  // =====================

  return (
    <div style={styles.container}>
      <form
        style={styles.card}
        onSubmit={handleSubmit}
      >
        <h1 style={styles.title}>
          Login
        </h1>

        <input
          type="email"
          placeholder="Enter Email"
          value={email}
          onChange={(e) =>
            setEmail(e.target.value)
          }
          style={styles.input}
        />

        <input
          type="password"
          placeholder="Enter Password"
          value={password}
          onChange={(e) =>
            setPassword(e.target.value)
          }
          style={styles.input}
        />

        <button
          type="submit"
          style={styles.button}
        >
          Login
        </button>
      </form>
    </div>
  );
}

export default LoginForm;