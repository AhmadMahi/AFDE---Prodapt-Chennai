import { useEffect, useState } from "react";

function Users() {
  // =========================
  // State
  // =========================

  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  // =========================
  // API Call
  // =========================

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await fetch(
          "https://jsonplaceholder.typicode.com/users"
        );

        if (!response.ok) {
          throw new Error("Failed to fetch users");
        }

        const data = await response.json();

        setUsers(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  // =========================
  // Styles
  // =========================

  const styles = {
    page: {
      padding: "30px",
      maxWidth: "1000px",
      margin: "0 auto",
    },

    title: {
      textAlign: "center",
      marginBottom: "30px",
      color: "#4f46e5",
    },

    cardContainer: {
      display: "grid",
      gridTemplateColumns:
        "repeat(auto-fit, minmax(250px, 1fr))",
      gap: "20px",
    },

    card: {
      padding: "20px",

      borderRadius: "20px",

      background: "rgba(255,255,255,0.15)",

      backdropFilter: "blur(20px)",

      boxShadow:
        "0 10px 30px rgba(0,0,0,0.1)",
    },

    name: {
      margin: 0,
      marginBottom: "10px",
      color: "#4f46e5",
    },

    text: {
      margin: "5px 0",
      color: "#555",
    },

    loading: {
      textAlign: "center",
      fontSize: "2rem",
      marginTop: "100px",
    },

    error: {
      textAlign: "center",
      color: "red",
      fontSize: "1.5rem",
      marginTop: "100px",
    },
  };

  // =========================
  // Loading State
  // =========================

  if (loading) {
    return (
      <h1 style={styles.loading}>
        Loading Users...
      </h1>
    );
  }

  // =========================
  // Error State
  // =========================

  if (error) {
    return (
      <h1 style={styles.error}>
        {error}
      </h1>
    );
  }

  // =========================
  // JSX
  // =========================

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>
        Users Directory
      </h1>

      <div style={styles.cardContainer}>
        {users.map((user) => (
          <div
            key={user.id}
            style={styles.card}
          >
            <h2 style={styles.name}>
              {user.name}
            </h2>

            <p style={styles.text}>
              📧 {user.email}
            </p>

            <p style={styles.text}>
              📞 {user.phone}
            </p>

            <p style={styles.text}>
              🌐 {user.website}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Users;