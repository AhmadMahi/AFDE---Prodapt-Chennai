function StudentCard({
  name,
  course,
  experience,
  city
}) {
  return (
    <div className="student-card">
      <h2>{name}</h2>

      <p>Course: {course}</p>

      <p>Experience: {experience}</p>

      <p>City: {city}</p>
    </div>
  );
}

export default StudentCard;