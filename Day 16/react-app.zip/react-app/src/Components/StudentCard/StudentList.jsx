function StudentList() {
  const students = [
    "Ahmed",
    "Ali",
    "Sara",
    "Fatima"
  ];

  return (
    <div>
      {students.map((student) => (
        <h2>{student}</h2>
      ))}
    </div>
  );
}

export default StudentList;