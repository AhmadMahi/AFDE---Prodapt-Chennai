import "./Header.css";

function Header() {
  return (
    <header className="header">
      <h1>Student Portal</h1>
      <nav>
        <a href="#">Home</a>
        <a href="#">Courses</a>
        <a href="#">About</a>
      </nav>
    </header>
  );
}

export default Header;