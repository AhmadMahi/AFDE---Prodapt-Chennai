function MyNewComp() {
    return ( 
       < div>
            <h1>My New Component</h1>
            <p>This is a new component that I created.</p>
        </div>
     );
}

export default MyNewComp;