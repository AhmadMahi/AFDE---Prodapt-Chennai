function Home() {
  return (
    <div>
      <h1>🏠 Home Page</h1>
      <p>Welcome to React Router</p>
    </div>
  );
}

export default Home;