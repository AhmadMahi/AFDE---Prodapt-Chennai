function Users() {
  return (
    <div>
      <h1>👥 Users Page</h1>
      <p>List of Users</p>
    </div>
  );
}

export default Users;